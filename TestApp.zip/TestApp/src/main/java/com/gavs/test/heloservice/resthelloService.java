package com.gavs.test.heloservice;

import org.springframework.stereotype.Service;

@Service
public class resthelloService {
	
	public String hello() {
		return "hello  hai good ";
	}

}
