package com.tritern.evozspecial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvozspecialApplication {

    public static void main(String[] args) {
        SpringApplication.run(EvozspecialApplication.class, args);
    }
}
